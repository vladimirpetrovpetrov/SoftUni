﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-3APE4MB;Database=Footballers;Integrated Security=True;Encrypt=False";
    }
}
